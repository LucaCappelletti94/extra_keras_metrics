keras_metrics
==================================================================
Additional metrics integrated with the keras NN library, taken directly from `Tensorflow 
<https://www.tensorflow.org/api_docs/python/tf/metrics/>`_..

How do I get this package?
----------------------------------------------
As usual, just install it with pip:

.. code: bash

    pip install keras_metrics