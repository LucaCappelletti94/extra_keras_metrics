"""Current version of package extra_keras_metrics"""
__version__ = "2.0.2"